# NetMon: Dashboard giám sát hiệu suất mạng

## Phần A: Collector (Python + Netmiko)

```bash
python -m venv venv && source venv/bin/activate      # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env                                  # điền NET_USERNAME / NET_PASSWORD
cp config/devices.example.yaml config/devices.yaml    # sửa IP cho đúng lab

python -m pytest -q                                   # chạy test
python -m collector.main --mock --once                # thử với dữ liệu giả
python -m collector.main --interval 15                # chạy thật
```

Cấu trúc: `collector/` (SSH, parse, lưu DB) · `alerts/` (luật cảnh báo) · `db/` (schema + hàm dùng chung) · `config/` · `tests/`

Quy ước chung với B: luôn mở DB bằng `db.database.connect()`, timestamp lấy từ `now_utc()`.
Lưu ý cho dashboard: `in_bps`/`out_bps` là NULL ở mẫu đầu tiên và khi thiết bị reset bộ đếm.
